# PT-Kit Link-Pause Firmware

This bundle contains only the active firmware for the ESP32-to-Arduino link-stability update.

## Scope

- Temporary communication loss: hold the last validated lamp/fan PWM.
- Arduino pause threshold: 3.5 seconds without a valid ESP32 output frame.
- Pause notification: repeated `V1:L` frames every 1 second.
- Hard link-fault cutoff: 10 seconds from the last valid ESP32 output frame.
- Hard cutoff behavior: lamp OFF, fan ON, `FAULT_LINK_TIMEOUT`.
- Fresh output acknowledgement resumes the controller.
- Experiment state and timers are frozen during the pause.
- Existing over-temperature, invalid-sensor, stale-frame, and local safety behavior remains active.
- No preheat, plateau, backend, UI, or unrelated experiment feature was changed.

## Contents

- `source/ESP32/ESP32.ino`
- `source/ESP32/ptkit_offload_controller.h`
- `source/ESP32/ptkit_offload_protocol.h`
- `source/ESP32/ESP32.local.h.example` — credential-free template only
- `source/Arduino/arduino_hardware.ino`
- `source/Arduino/ptkit_offload_protocol.h`
- `binaries/ESP32.ino.bootloader.bin`
- `binaries/ESP32.ino.partitions.bin`
- `binaries/ESP32.ino.bin`
- `binaries/boot_app0.bin`
- `binaries/arduino_hardware.ino.with_bootloader.hex`
- `verification/test_offload_controller.cpp`
- `verification/test_offload_protocol.cpp`

No `ESP32.local.h`, credentials, private CA, backend configuration, legacy firmware, or application files are included.

## Tested build

- Arduino AVR Boards: `1.8.6`
- ESP32 Arduino core: `2.0.17` (binary build verified here)
- ESP32 source compatibility: core `2.x` and `3.x` enterprise-Wi-Fi signatures are selected automatically
- ESP32 board target: `esp32:esp32:esp32`
- LiquidCrystal_I2C: `2.0.0`
- Adafruit MLX90614 Library: `2.1.6`
- Adafruit BusIO: `1.17.4`
- BH1750: `1.3.0`
- MAX6675 library with `readCelsius()` API, such as Adafruit's MAX6675 library

The source and binaries in this archive were compiled successfully with these targets.

## Arduino IDE source flashing

1. Install the libraries listed above.
2. Open `source/ESP32/ESP32.local.h.example`, replace placeholders locally, and save it as `ESP32.local.h` beside `ESP32.ino`. Never commit or share that file.
3. Open `source/ESP32/ESP32.ino` in the Arduino IDE and select the ESP32 board used by the deployment.
4. Flash the ESP32 first.
5. Verify the USB serial boot banner contains `PTKIT_CONNECTIVITY_V9`.
6. Open `source/Arduino/arduino_hardware.ino` and select Arduino Uno.
7. Flash the Arduino Uno second.
8. Do not run the legacy ESP32 firmware alongside this offload pair.

## Binary flashing

For ESP32, use the bootloader, partition table, boot-app0, and application binaries together:

```text
esptool.py --chip esp32 write_flash -z \
  0x1000 binaries/ESP32.ino.bootloader.bin \
  0x8000 binaries/ESP32.ino.partitions.bin \
  0xe000 binaries/boot_app0.bin \
  0x10000 binaries/ESP32.ino.bin
```

For the Uno, the bundled Intel HEX includes the bootloader and application:

```text
avrdude -p atmega328p -c arduino -P <PORT> -b 115200 -D \
  -U flash:w:binaries/arduino_hardware.ino.with_bootloader.hex:i
```

Replace `<PORT>` with the actual serial device. Confirm the board and port before flashing.

## Verification hashes

```text
e4e64f559865692bf483a2cf1d8cca4299271eaf62082e68938f2748b8545780  arduino_hardware.ino.with_bootloader.hex
9e56d96d4998314dad023fd136d491b38e41b333f0cd081072b69a7d50167581  ESP32.ino.bin
148b959cbff1c38aa8e1d5c0ba9d612c54997b945e56a63f41223eef650653a1  ESP32.ino.partitions.bin
```
